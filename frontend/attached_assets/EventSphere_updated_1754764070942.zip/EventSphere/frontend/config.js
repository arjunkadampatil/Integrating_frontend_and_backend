// frontend/config.js
// Use your backend's Render URL in production
//const BASE_URL = "https://event-projrct-1.onrender.com"; 

// For local development, you would use:
 const BASE_URL = "http://localhost:3000";